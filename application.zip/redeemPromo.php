<?php
include("src/functions.php");
session_start();
$id = $_GET['id'];
if($_SESSION['id'] != $id){
  header("location: restrict.php");
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $id = $_GET['id'];
  $promo_id = $_GET['promo_id'];
  $error = False;
  if(is_int($id) && is_int($promo_id)){
    echo "The user id and promo ids must be integers";
    $error = True;
  }

  if($_SESSION['id'] != $id){
    echo "Invalid user ID";
    $error = True;
  }

  if($error == False){
    $result = query("userpromos", "*", array("User_ID" => $id, "Promo_ID" => $promo_id));

    if($result->num_rows == 0){
      echo "Unable to redeem.  You don't actually have this promo legitimately purchased.";
}
    else{
      echo "Promo has been successfully redeemed.";
      deleteQuery("userpromos", "User_ID=".$id." AND Promo_ID=".$promo_id);
    }
  }
  else{
    echo "There was an error";
  }
  echo "<button><a href='dashboard.php?id=".$_SESSION['id']."'>Click here to go back to your dashboard</a></button>";
}
 ?>

<html>
<form method='post' action='' id='form'>
  <div id='div'>NOTE: Clicking the button will redeem the promo.  Make sure an employee is present.</div>
  <button id='button' type="submit" id="submit" onclick='redirect()'>Redeem this Promo</button>
</form>
</html>

<script>
  function redirect(){
    var el = document.getElementById('form');
    //var el2 = document.getElementById('button');

    el.style.display = 'none';
    //el2.style.visibility = 'hidden';
  }

</script>
