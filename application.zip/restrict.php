<?php
echo "That's restricted";
 ?>

 <script>
console.log("DAC converts 100 into a voltage");
console.log("ADC2 converts 0.081 V into 0x64");

console.log("DAC converts 400 into a voltage");
console.log("ADC2 converts 0.322 V into 0x190");

console.log("DAC converts 800 into a voltage");
console.log("ADC2 converts 0.644 V into 0x320");

console.log("DAC converts 1200 into a voltage");
console.log("ADC2 converts 0.967 V into 0x4B0");

console.log("DAC converts 1600 into a voltage");
console.log("ADC2 converts 1.288 V into 0x640");

console.log("DAC converts 2000 into a voltage");
console.log("ADC2 converts 1.61 V into 0x7D0");

console.log("DAC converts 2400 into a voltage");
console.log("ADC2 converts 1.934 V into 0x960");

console.log("DAC converts 2800 into a voltage");
console.log("ADC2 converts 2.254 V into 0xAF0");

console.log("DAC converts 3200 into a voltage");
console.log("ADC2 converts 2.576 V into 0xC80");

console.log("DAC converts 3600 into a voltage");
console.log("ADC2 converts 2.898 V into 0xE10");

console.log("DAC converts 4000 into a voltage");
console.log("ADC2 converts 3.220 V into 0xFA0");

 </script>
