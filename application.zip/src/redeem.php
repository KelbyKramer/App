<?php
echo "Page to redirect to for redeeming promos";
 ?>
